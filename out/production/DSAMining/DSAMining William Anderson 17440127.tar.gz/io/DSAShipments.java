package io;

/**
 * Created with IntelliJ IDEA.
 * User: Bill
 * Date: 8/09/13
 * Time: 4:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class DSAShipments
{
    /** Main method, kicks the whole thing off
     *
     * @param arg
     */
    public static void main(String[] arg)
    {
        DSAShipmentManager manager = new DSAShipmentManager();
        manager.run();
    }
}
